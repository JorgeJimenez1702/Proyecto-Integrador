#include <iostream>
#include <string>
#include "Fecha.h" 
using namespace std;

class Persona{
protected:
    string nom;
    string direcc;
    int tel;
    string se;
    Fecha fechaNac;
public:
    Persona();
    Persona(string nombre, string direccion, int telefono, Fecha nacimiento, string sexo);
    void setNombre(string){return nom;}
    void setDireccion(string){return direcc;}
    string getNombre();
    string getDireccion();
};