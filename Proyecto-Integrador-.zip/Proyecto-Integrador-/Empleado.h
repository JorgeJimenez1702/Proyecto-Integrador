#ifndef SUCURSAL_H
#define SUCURSAL_H
#include "Sucursal.h"
#include "Persona.h"
using namespace std;


class Empleado : public Persona{
private:
    string cargo;
    string id;
    Sucursal sucursal;
public:
    Empleado();
    Empleado(string Nombre, string Direccion, int Telefono, Fecha Nacimiento, string Sexo, string Cargo, Sucursal suc);
    //Si no podemos lograr que se generen automaticamente los ID's 
    //de los empleados debemos volver a incorporarlo como un parámetro del método.
    void modificarCargo(string car);
    void modificarCargo(string car, string idEmpleado);
    string getId();

};
#endif