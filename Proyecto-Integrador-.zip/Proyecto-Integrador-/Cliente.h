//Modificado
#pragma once
#include "Empleado.h"
#include "Persona.h"

class Cliente : public Persona{
private:
    string RFC;

public:
    Cliente();
    Cliente(string nombre, string direccion, int telefono, Fecha nacimiento, string sexo, string RFC); //¿como recibir un parametro hereditario?
    string getRFC();
    void setRFC(string);
};
