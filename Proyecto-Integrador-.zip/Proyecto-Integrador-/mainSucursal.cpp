#include "Sucursal.h"
#include <iostream>

using namespace std;

main()
{
    Sucursal*lista = new Sucursal[10];
}