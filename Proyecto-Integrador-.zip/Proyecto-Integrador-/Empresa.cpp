//Creada
#include "Empresa.h"
#include <iostream>
using namespace std;

//Constructor sin argumentos
Empresa::Empresa(){
    listaSucursales = new Sucursal[1];
    sizeSucursales = 1;
    sizeMemSucursales = 1;
    listaClientes = new Cliente[1];
    sizeClientes = 1;
    sizeMemClientes = 1;
}

//Constructor con arreglo especifico
Empresa::Empresa(int s, Sucursal * listaSuc, int s2, Cliente * listaCli){
    listaSucursales = listaSuc;
    sizeSucursales = s;
    sizeMemSucursales = s;
    listaClientes = listaCli;
    sizeClientes = s;
    sizeMemClientes = s;
}

int Empresa::getSizeSucursales(){
    return sizeSucursales;
}

int Empresa::getSizeClientes(){
    return sizeClientes;
}

int Sucursal::buscarSucursal(string idSuc, Sucursal*list, int sucExistentes)
{
    for (int i=0; i<sucExistentes;i++)
    {
        if(list[i].getIdSuc()==idSuc)
        {return i;}
        else {return -1;}
    }
}

/*void Sucursal::modificarSucursal(int ID, string dir, string ciu, string est, string pa)
//Podra modificar el ID, la dirección, ciudad, estado y país.
{
    idSucursal = ID;
    direcSuc = dir;
    ciudad = ciu;
    estado = est;
    pais = pa;
}
*/

void Sucursal::agregarSucursal(Sucursal s){
    if(sizeSucursales+1 > sizeMemSucursales){
        //Se crea un nuevo arreglo de fracciones con el doble de memoria
        Sucursal * NewSucursal = new Sucursal[sizeSucursales*2];
        //Se copia el arreglo en el nuevo arreglo
        for (int i=0; i<size; i++){
            NewSucursal[i] = listSucur[i];
        }
        NewSucursal[size+1] = f;
        arr = newArr;
        sizeMem = size*2;
        size = size+1;
    }else{
        //Si hay suficiente memoria reservado, entonces, simplemente agregalo
        arr[size+1] = f;
        size++;
    }   
}





