#include "Empleado.h"

using namespace std;

Empleado::Empleado():Persona()
{
    cargo = "";
    id = "";
};

Empleado::Empleado(string Nombre, string Direccion, int Telefono, Fecha fechaNacimiento, string Sexo, string Cargo,Sucursal suc):Persona (Nombre, Direccion, Telefono,fechaNacimiento,Sexo)
{
    string cargo = Cargo;
    //string id = Id;
    sucursal = suc;
    sucursal.agregarEmpleado(*this);
}

void Empleado::modificarCargo(string car) //De un objeto tipo empleado.
{
    cargo = car;    
}

//Modificar el cargo del empleado desde la lista general.
void Empleado::modificarCargo(string car, string idEmp)
{
    
}