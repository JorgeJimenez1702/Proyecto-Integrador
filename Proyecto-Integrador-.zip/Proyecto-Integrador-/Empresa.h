//Creada
#include <string>
#include "Sucursal.h"
#include "Cliente.h"
using namespace std;

class Empresa
{
    private:
        Sucursal * listaSucursales;
        int sizeSucursales;
        int sizeMemSucursales;
        Cliente * listaClientes;
        int sizeClientes;
        int sizeMemClientes;
        
    public:
    Empresa();
    Empresa(int ,Sucursal *, int , Cliente *);
    int getSizeSucursales();
    int getSizeClientes();
    //int buscarSucursal(int IdSucu);
    void agregarSucursal(Sucursal);
    void quitarSucursal(int IdSucu);
    //void modificarSucursal(int IdSucu, Sucursal s);
    //int buscarCliente(int Id);
    void agregarCliente(Cliente);
    void quitarCliente(int IdClien);
    //void modificarCliente(Cliente*listaclin);

}