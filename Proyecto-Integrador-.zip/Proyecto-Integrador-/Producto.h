//Modificada
#include <string>
using namespace std;
class Producto
{
    private:
    int codigoProducto;
    string nombreProducto;
    float costo;
    float precio;
    float peso;
    float tamanoEmpaque;

    public:
    Producto();
    Producto(int codProd, string nomProd, float cos,float pre,float p, float tamE);
    int getCodigoProducto(){return codigoProducto;}
    string getNombreProducto(){return nombreProducto;}
    float getPrecioCompra(){return costo;}
    float getPrecioVenta(){return precio;}
    float getPeso(){return peso;}
    float getTamanoEmpaque(){return tamanoEmpaque;}
    void showProductoCPV();
    void showProductoCompleto();
    //void setTamanoEmpaque(float);
    //void setCodigoProducto(string);
    //void setPrecioCompra(float);
    //void setPeso(float);
};
