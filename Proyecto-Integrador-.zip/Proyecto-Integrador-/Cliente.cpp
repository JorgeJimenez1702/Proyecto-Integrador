#include "Cliente.h"
using namespace std;

Cliente::Cliente() : Persona (){
    RFC = "";
};

Cliente::Cliente(string erreFC):Persona(nombre, direccion, telefono, fechaNacimiento, sexo){
    string RFC = erreFC;
}
string Cliente::getRFC()
{
    return RFC;
}
void Cliente::setRFC(string rfc)
{
    RFC = rfc;
}
