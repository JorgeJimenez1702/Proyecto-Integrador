//Modificada
#include "Sucursal.h"
#include <iostream>
using namespace std;

Sucursal::Sucursal()
{
    idSucursal = "Default";
    direcSucursal = "Direccion default.";
    ciudad = "Ciudad default.";
    estado = "Estado default.";
    pais = "Pais default.";
    cntdEmp = 0;
    Inventario invt;
    Empleado e;
    listaEmpleados = new Empleado[1];
}

Sucursal::Sucursal(int ID, string dir, string ciu, string est, string pa, Inventario global, Empleado*listaEmp)
{
    idSucursal = ID;
    direcSucursal = dir;
    ciudad  = ciu;
    estado = est;
    pais = pa;
    //nEmpleados es elcontador que debería modificarse solo con los métodos.
    inventarioGlobal = global; 
    listaEmpleados = listaEmp;   
}
/* void Sucursal::modificarSucursal(int ID, string dir, string ciu, string est, string pa)
//Podra modificar el ID, la dirección, ciudad, estado y país.
{
    idSucursal = ID;
    direcSuc = dir;
    ciudad = ciu;
    estado = est;
    pais = pa;
}
*/

/*void Sucursal::quitarSucursal(string idSuc, Sucursal*list, int sucExistentes)
{
    int i = buscarSucursal(idSuc, list, sucExistentes);
        if(i>=0){
            list[i]=list[sucExistentes-1];
            list[sucExistentes-1]=list[sucExistentes];
            sucExistentes--;

            cout<<"Ha eliminado la sucursal ->"<<idSuc<<". La cantidad de sucursales existentes actualmente es:" <<sucExistentes<<endl;
        }   
        else
        {
            cout<<idSuc<< ": Esta sucursal no ha sido encontrada."<< endl;
        }
}
*/
/*
int Sucursal::buscarSucursal(string idSuc, Sucursal*list, int sucExistentes)
{
    for (int i=0; i<sucExistentes;i++)
    {
        if(list[i].getIdSuc()==idSuc)
        {return i;}
        else {return -1;}
    }
}
*/

/*void Sucursal::agregarSucursal(Sucursal nueva, Sucursal*list,int sucursalesExistentes)
{
    list[sucursalesExistentes]= nueva; //¿Así está bien definido el índice? 
}
*/

void Sucursal::agregarEmpleado(Empleado e)
{
    listaEmp[cntdEmp] = e;
    cntdEmp++;
}

void Sucursal::quitarEmpleado(string idEmpleado)
{
    int indice;
    for(int i=0;i<cntdEmp;i++)
    {
        if(listaEmp[i].getId()==idEmpleado)
        {
            indice = i;
        }
        else{indice = -2;}
    }
    if(indice<0)
    {
        cout<<"El empleado con ID: "<<idEmpleado<<" no ha sido encontrado."<<endl;
    }
    else
    {
        listaEmp[indice]=listaEmp[cntdEmp-1];
        listaEmp[cntdEmp-1]=listaEmp[cntdEmp];
        cntdEmp--;

        cout<<"El empleado con ID: "<<idEmpleado<<"ha sido eliminado del registro."<<endl;
    }   
}

