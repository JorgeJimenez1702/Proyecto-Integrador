#include "Persona.h"
#include <iostream>

using namespace std;

Persona::Persona(){
    nom = "";
    direcc = "";
    tel = 0;
    se = "";
    Fecha f1;
    fechaNac = f1;
}

Persona::Persona(string Nombre, string Direccion, int Telefono, Fecha fechaNacimiento, string Sexo){
    nom = Nombre;
    direcc = Direccion;
    tel = Telefono;
    se = Sexo;
    fechaNac = fechaNacimiento;
}
